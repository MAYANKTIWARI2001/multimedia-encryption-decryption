from tkinter import Tk, Button, filedialog, Label, Entry
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from PIL import Image

root = Tk()

def encrypt_image(key, input_file, output_file):
    # Open the input image
    input_image = Image.open(input_file)

    # Convert the image to RGB mode
    input_image = input_image.convert('RGB')

    # Get the size of the input image
    width, height = input_image.size

    # Create a new image for the encrypted output
    encrypted_image = Image.new('RGB', (width, height))

    # Initialize the AES cipher
    cipher = AES.new(key, AES.MODE_ECB)

    # Process the image block by block
    for y in range(0, height, AES.block_size):
        for x in range(0, width, AES.block_size):
            # Get the block of pixel data
            block = input_image.crop((x, y, x + AES.block_size, y + AES.block_size))

            # Convert the block to bytes
            block_bytes = block.tobytes()

            # Encrypt the block bytes
            encrypted_block = cipher.encrypt(block_bytes)

            # Create an image from the encrypted block
            encrypted_block_image = Image.frombytes('RGB', (AES.block_size, AES.block_size), encrypted_block)

            # Paste the encrypted block into the output image
            encrypted_image.paste(encrypted_block_image, (x, y))

    # Save the encrypted image
    encrypted_image.save(output_file)
    print("Encryption completed.")

def decrypt_image(key, input_file, output_file):
    # Open the input image
    input_image = Image.open(input_file)

    # Get the size of the input image
    width, height = input_image.size

    # Create a new image for the decrypted output
    decrypted_image = Image.new('RGB', (width, height))

    # Initialize the AES cipher
    cipher = AES.new(key, AES.MODE_ECB)

    # Process the image block by block
    for y in range(0, height, AES.block_size):
        for x in range(0, width, AES.block_size):
            # Get the block of encrypted pixel data
            block = input_image.crop((x, y, x + AES.block_size, y + AES.block_size))

            # Convert the block to bytes
            block_bytes = block.tobytes()

            # Decrypt the block bytes
            decrypted_block = cipher.decrypt(block_bytes)

            # Create an image from the decrypted block
            decrypted_block_image = Image.frombytes('RGB', (AES.block_size, AES.block_size), decrypted_block)

            # Paste the decrypted block into the output image
            decrypted_image.paste(decrypted_block_image, (x, y))

    # Save the decrypted image
    decrypted_image.save(output_file)
    print("Decryption completed.")

def select_input_file():
    file_path = filedialog.askopenfilename(title="Select Input Image")
    input_entry.delete(0, 'end')
    input_entry.insert('end', file_path)

def select_output_file():
    file_path = filedialog.asksaveasfilename(title="Save Output Image")
    output_entry.delete(0, 'end')
    output_entry.insert('end', file_path)

def encrypt_button_clicked():
    key = bytes(key_entry.get(), 'utf-8')
    input_file = input_entry.get()
    output_file = output_entry.get()
    encrypt_image(key, input_file, output_file)

def decrypt_button_clicked():
    key = bytes(key_entry.get(), 'utf-8')
    input_file = input_entry.get()
    output_file = output_entry.get()
    decrypt_image(key, input_file, output_file)

# Labels
Label(root, text="Key:").grid(row=0, column=0)
Label(root, text="Input Image:").grid(row=1, column=0)
Label(root, text="Output Image:").grid(row=2, column=0)

# Key Entry
key_entry = Entry(root, width=30)
key_entry.grid(row=0, column=1)

# Input File Entry and Select Button
input_entry = Entry(root, width=30)
input_entry.grid(row=1, column=1)
Button(root, text="Select", command=select_input_file).grid(row=1, column=2)

# Output File Entry and Select Button
output_entry = Entry(root, width=30)
output_entry.grid(row=2, column=1)
Button(root, text="Select", command=select_output_file).grid(row=2, column=2)

# Encrypt and Decrypt Buttons
Button(root, text="Encrypt", command=encrypt_button_clicked).grid(row=3, column=0)
Button(root, text="Decrypt", command=decrypt_button_clicked).grid(row=3, column=1)

root.mainloop()